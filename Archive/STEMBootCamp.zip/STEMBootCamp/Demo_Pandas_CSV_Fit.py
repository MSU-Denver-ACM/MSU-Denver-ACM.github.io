#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 13:45:06 2019
https://blog.datarobot.com/ordinary-least-squares-in-python
@author: fengjiang
"""
#https://blog.datarobot.com/ordinary-least-squares-in-python
# load numpy and pandas for data manipulation
import numpy as np
import pandas as pd
# load statsmodels as alias ``sm``

import statsmodels.api as sm
import matplotlib.pyplot as plt
# load the longley dataset into a pandas data frame - first column (year) used as row labels
df = pd.read_csv('http://vincentarelbundock.github.io/Rdatasets/csv/datasets/longley.csv', index_col=0)

df.to_csv('./test.csv')
df.head()


y = df.Employed  # response

X = df.GNP  # predictor

X = sm.add_constant(X)  # Adds a constant term to the predictor

X.head()


#print(est.summary())
X2 = df.Year 
Y2 = df.Population
X2 = sm.add_constant(X2)


est2=sm.OLS(Y2,X2)
est2 = est2.fit()

X2plot=np.linspace(X2.Year.min(), X2.Year.max()+10, 100)[:, np.newaxis]
X2plot = sm.add_constant(X2plot)
y2_hat = est2.predict(X2plot)
plt.figure()
plt.scatter(X2.Year, Y2, alpha=0.3) # Plot the raw data
plt.xlabel("Year")
plt.ylabel("Population")
plt.plot(X2plot[:,1], y2_hat, 'r', alpha=0.9) 

testSort=df.sort_values('GNP')

print (df.describe())

plt.figure()
df.plot(kind='bar',x='Year',y='GNP')
plt.show()
ax = plt.gca()
df.plot(kind='line',x='Year',y='Population',ax=ax)
df.plot(kind='line',x='Year',y='GNP', color='red', ax=ax)
df.plot(kind='line',x='Year',y='Unemployed', color='black', ax=ax)
plt.show()
plt.savefig('test_output.png')

 

df2=df
df['GNP']=np.where(df['GNP'] <300, 'less_than_300', 'more_than_300')
plotGNP = df.GNP.value_counts()
plotGNPname = ['less than 300', 'more than 300']
plt.pie(plotGNP, labels=plotGNPname, startangle=90, autopct='%.1f%%')
 
