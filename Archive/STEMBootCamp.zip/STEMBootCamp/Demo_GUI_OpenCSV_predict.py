try:
    # Python 2
    import Tkinter as tk
    import ttk
    from tkFileDialog import askopenfilename
except ImportError:
    # Python 3
    import tkinter as tk
    from tkinter import ttk
    from tkinter.filedialog import askopenfilename

import pandas as pd
from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
# Implement the default Matplotlib key bindings.
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
# load statsmodels as alias ``sm``
import statsmodels.api as sm
import numpy as np


# --- classes ---

class MyWindow:

    def __init__(self, parent):

        self.parent = parent

        self.filename = None
        self.df = None

        self.text = tk.Text(self.parent)
        self.text.pack()

        self.button = tk.Button(self.parent, text='LOAD DATA', command=self.load)
        self.button.pack()

        self.button = tk.Button(self.parent, text='DISPLAY DATA', command=self.display)
        self.button.pack()

    def load(self):

        name = askopenfilename(filetypes=[('CSV', '*.csv',), ('Excel', ('*.xls', '*.xlsx'))])

        if name:
            if name.endswith('.csv'):
                self.df = pd.read_csv(name)
                #df = pd.read_csv('http://vincentarelbundock.github.io/Rdatasets/csv/datasets/longley.csv', index_col=0)
               
                
            else:
                self.df = pd.read_excel(name)

            self.filename = name

            # display directly
            #self.text.insert('end', str(self.df.head()) + '\n')

    def display(self):
        # ask for file if not loaded yet
        if self.df is None:
            self.load()

        # display if loaded
        if self.df is not None:
            self.text.insert('end', self.filename + '\n')
            self.text.insert('end', str(self.df.head()) + '\n')
            #self.text.insert('end','Data predicting for future 10 years:\n')
            X2 = self.df.Year 
            Y2 = self.df.Population
            X2 = sm.add_constant(X2)
            est2=sm.OLS(Y2,X2)
            est2 = est2.fit()
            X2plot=np.linspace(X2.Year.min(), X2.Year.max()+10, 100)[:, np.newaxis]
            X2plot = sm.add_constant(X2plot)
            y2_hat = est2.predict(X2plot)
            self.text.insert('end','Data predicting after 1962:'+'\n\n\n')
            self.text.insert('end', str(y2_hat[90]) + '\n')
            self.text.insert('end', str(y2_hat[91]) + '\n')
            self.text.insert('end', str(y2_hat[92]) + '\n')
            self.text.insert('end', str(y2_hat[93]) + '\n')
            self.text.insert('end', str(y2_hat[94]) + '\n')
            self.text.insert('end', str(y2_hat[95]) + '\n')
            self.text.insert('end', str(y2_hat[96]) + '\n')
            self.text.insert('end', str(y2_hat[97]) + '\n')
            self.text.insert('end', str(y2_hat[98]) + '\n')
            self.text.insert('end', str(y2_hat[99]) + '\n')
 

# --- main ---

if __name__ == '__main__':
    root = tk.Tk()
 
    top = MyWindow(root)

    root.mainloop()