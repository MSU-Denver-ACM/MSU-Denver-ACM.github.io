#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 28 13:09:10 2019
Demo of GUI_plot_matplotlib
@author: fengjiang
"""
import tkinter

from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
# Implement the default Matplotlib key bindings.
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
import pandas as pd
# load statsmodels as alias ``sm``
import statsmodels.api as sm
import numpy as np


root = tkinter.Tk()
root.wm_title("Embed Figure in Tk")

df = pd.read_csv('http://vincentarelbundock.github.io/Rdatasets/csv/datasets/longley.csv', index_col=0)
X2 = df.Year 
Y2 = df.Population
X2 = sm.add_constant(X2)
est2=sm.OLS(Y2,X2)
est2 = est2.fit()
X2plot=np.linspace(X2.Year.min(), X2.Year.max()+10, 100)[:, np.newaxis]
X2plot = sm.add_constant(X2plot)
y2_hat = est2.predict(X2plot)


fig = Figure(figsize=(6, 5), dpi=100)
fig.add_subplot(111).plot(X2plot[:,1], y2_hat,color='red')
fig.add_subplot(111).scatter(X2.Year, Y2, alpha=0.3) # Plot the raw data
fig.text(0.5, 0.04, 'Year', ha='center')
fig.text(0.04, 0.5, 'Population', va='center', rotation='vertical')
 

canvas = FigureCanvasTkAgg(fig, master=root)  # A tk.DrawingArea.
canvas.draw()
canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)

toolbar = NavigationToolbar2Tk(canvas, root)
toolbar.update()
canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)


def on_key_press(event):
    print("you pressed {}".format(event.key))
    key_press_handler(event, canvas, toolbar)


canvas.mpl_connect("key_press_event", on_key_press)


def _quit():
    root.quit()     # stops mainloop
    root.destroy()  # this is necessary on Windows to prevent
                    # Fatal Python Error: PyEval_RestoreThread: NULL tstate


button = tkinter.Button(master=root, text="Quit", command=_quit)
button.pack(side=tkinter.BOTTOM)

tkinter.mainloop()
