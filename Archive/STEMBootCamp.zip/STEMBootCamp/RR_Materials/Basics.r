#Author:  Ranjidha Rajan
#Workshop in R @ MSU

#setwd("F:/MSU/2019Spring/Workshop_DataAnalysis/MySlide")
getwd()


#R Basics

n <- 15
n

5 -> m
m

x <- 1
X <- 10
x
X

n <- 10 + 2
 n
n<-(10 + 2) * 5
n


sqrt(4)


myString <- "Hello, World!"
print ( myString)

# My first program in R Programming
V<-c(1,2,3,4)
V
length(V)

Vchar<-as.character(V)
#List

MyList<-list(c(1,2,3),c("a","b"))
MyList

Mylist[[1]]

#Matrix
M = matrix( c('a','a','b','c','b','a'), nrow = 2, ncol = 3, byrow = TRUE)
print(M)

#Factors
# Create a vector.
apple_colors <- c('green','green','yellow','red','red','red','green')

# Create a factor object.
factor_apple <- factor(apple_colors)

# Print the factor.
print(factor_apple)
print(nlevels(factor_apple))


# Create the data frame.
BMI <- 	data.frame(
  gender = c("Male", "Male","Female"), 
  height = c(152, 171.5, 165), 
  weight = c(81,93, 78),
  Age = c(42,38,26)
)
print(BMI)


var_x <- 34.5
cat("  Now the class of var_x is ",class(var_x),"\n")


#Functions
RMSE <- function(x,y){
  a <- sqrt(sum((log(x)-log(y))^2)/length(y))
  return(a)
}

RMSE(3,3)



