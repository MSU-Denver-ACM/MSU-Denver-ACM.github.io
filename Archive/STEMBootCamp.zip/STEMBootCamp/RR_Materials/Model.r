
#Author:  Ranjidha Rajan
#Workshop in R @ MSU

#Regression
# 10 Values of height

#151, 174, 138, 186, 128, 136, 179, 163, 152, 131

# 10 Values of weight.

#63, 81, 56, 91, 47, 57, 76, 72, 62, 48

ht <- c(151, 174, 138, 186, 128, 136, 179, 163, 152, 131)
wt <- c(63, 81, 56, 91, 47, 57, 76, 72, 62, 48)

# Apply the lm() function for linear regression model.
relation <- lm(wt~ht)

print(relation)
print(summary(relation))

# Find weight of a person with height 170.
a <- data.frame(ht = 170)
result <-  predict(relation,a)
print(result)

#```````````````````````````````````````````````
#Multiple 
input <- mtcars[,c("mpg","disp","hp","wt")]

#mileage per gallon (mpg), cylinder displacement("disp"), horse power("hp"), weight of the car("wt")
print(head(input))

model <- lm(mpg~disp+hp+wt, data = input)

# Show the model.
print(model)

# Get the Intercept and coefficients as vector elements.
cat("# # # # The Coefficient Values # # # ","\n")

a <- coef(model)[1]
print(a)

Xdisp <- coef(model)[2]
Xhp <- coef(model)[3]
Xwt <- coef(model)[4]

print(Xdisp)
print(Xhp)
print(Xwt)

#Y = 37.15+(-0.000937)*x1+(-0.0311)*x2+(-3.8008)*x3
#`````````````````````````````````````````
#Feature Selection
library(MASS)
#Stepwise selection from previous model
model_feature<- stepAIC(model, direction="both")

summary(model_feature)



#Classification using Decision Tree

library(rpart)

library(rpart.plot)
# Normalization of all columns except Species
dataNorm <- iris
dataNorm[,-5] <- scale(iris[,-5])

#Classification
# 70% train and 30% test

ind <- sample(2, nrow(dataNorm), replace=TRUE, prob=c(0.7,0.3))
trainData <- dataNorm[ind==1,]
testData <- dataNorm[ind==2,]

model_rpart<-rpart(Species ~ .,trainData,method="class",control = rpart.control(cp = 0))
testData$pred<-predict(model_rpart,testData,type="class")
summary(model_rpart)



#Confusion Matrix
table(testData$Species,testData$pred)


# Accuracy on test data
mean(testData$Species==testData$pred)

#Plot model
rpart.plot(model_rpart, type = 1)


###########################################
library(randomForest)
model_rf<-randomForest(Species ~ .,trainData)
testData$pred_rf<-predict(model_rf,testData)

importance(model_rf)
table(testData$Species,testData$pred_rf)

# Accuracy on test data
mean(testData$Species==testData$pred_rf)



############################################

library(e1071)

model_svm<-svm(Species ~ .,trainData)
summary(model_svm)

testData$pred_svm<-predict(model_svm,testData)
#confusion Matrix
table(testData$Species,testData$pred_svm)

# Accuracy on test data
mean(testData$Species==testData$pred_svm)
#############################################

library(cluster)
iris_data <- read.csv("Iris.csv")

data_clust<-iris
clust <- pam(data_clust,3)
plot(clust)
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Can do Hopkins statistic for cluster tendency

#``````````````````````````````````````

# 1 Select only first four columns of iris dataset
data <- iris_data[,1:4]

# 1 Create an empty vector: tot_wss
#     It will store total_within_sum_of_squares for various no of clusters
tot_wss<-c()

# 1 Do kmeans 15 times for various clusters, 1 to 15
#     & each time, note total of within sum of squares of each cluater
#      Iterate for clusters 1 to 15. Start with choice of just one cluster
for (i in 1:12)
{
  cl <- kmeans(data, centers=i)     # Do kmeans for i-th cluster
  tot_wss[i]<-cl$tot.withinss       # Note the tot.withinss for i-th cluster
}

#    Use plot function to plot values of tot_wss against no-of-clusters
plot(x=1:12,                         # x= No of clusters, 1 to 15
     y=tot_wss,                      # tot_wss for each
     type="b",                       # Draw both points as also connect them
     xlab="Number of Clusters",
     ylab="Within groups sum of squares")



