library(gWidgets)
library(gWidgetsRGtk2)


obj <- gbutton("Hello world", container = gwindow())

obj <- glabel("Hello world", container = gwindow())
obj <- gedit("Hello world", container = gwindow())
obj <- gtext("Hello world", container = gwindow())
obj <- gradio(c("hello","world"), container=gwindow())
obj <- gcombobox(c("hello","world"), container=gwindow())
obj <- gcombobox(c("hello","world"), editable=TRUE, container=gwindow())

obj <- gslider(from=0, to = 7734, by =100, value=0,container=gwindow())
obj <- gspinbutton(from=0, to = 7734, by =100, value=0,container=gwindow())
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Container
win <- gwindow("Hello World, ad nauseum", visible=TRUE)
group <- ggroup(horizontal = FALSE, container=win)
obj <- gbutton("Hello...",container=group, handler = function(h,...) gmessage("world"))
obj <- glabel("Hello...", container =group,+ handler = function(h,...) gmessage("world"))
obj <- gcombobox(c("Hello","world"), container=group)
obj <- gedit("Hello world", container=group)
obj <- gtext("Hello world", container=group, font.attr=list(style="bold"))