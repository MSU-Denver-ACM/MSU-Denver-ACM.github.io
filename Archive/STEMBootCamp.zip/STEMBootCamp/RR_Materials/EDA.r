

#Author:  Ranjidha Rajan
#Workshop in R @ MSU

#Set the working directory 


# read the iris data set
iris_data <- read.csv("Iris.csv")

# will have a look into the data
head(iris_data,3)
#Data Dimensions
dim(iris_data)
#To view column names
names(iris_data)
#Class of data
class(iris_data)

# To check the summary of the iris data set
summary(iris_data)

#checking for missing values
length(iris_data[is.na(iris_data)])
# To avoid missing values
na.omit(iris_data)


#mean
mean(iris_data$SepalLengthCm)
#help
?median


#Univariant analysis
# histogram of individual column
hist(iris_data$SepalLengthCm)
hist(iris_data$SepalLengthCm, col = "skyblue", xlab = "Sepal Length", main = 
       "Histogram of Sepal Lenght of Iris Data")


# check the species data with pie chart
table(iris_data$Species)
pie(table(iris_data$Species), main = "Pie Chart of the Iris data set Species", 
    col = c("orange1", "chocolate", "coral"), radius = 1)


## Explore multiple data
plot(iris_data$SepalLengthCm,iris_data$PetalLengthCm)

# Check the covariance and correlation between variables
print("covariance between variables")
cov(iris_data[, 1:4])

# correlation is positive when the values increases together
# correlation in negative when the values decreses together
print("correlation between variables")
cor(iris_data[, 2:5])

library(corrplot)
corPlotObj <- cor(iris_data[-c(1,6)])
corrplot(corPlotObj, method = "circle")


library(FSelector)
information.gain(Species~., iris_data)


#outlier analysis
boxplot(iris_data$SepalLengthCm,iris_data$SepalWidthCm,iris_data$PetalLengthCm,iris_data$PetalWidthCm)

# Will check the stats of "SepalLengthCm" wrt to Species
aggregate(SepalLengthCm  ~ Species, iris_data, summary)


# will see the data distribution using box plot
par(mfrow=c(2,2))
boxplot(SepalLengthCm  ~ Species, iris_data, main = "Sepal Length wrt Species", col = "lightpink3")
boxplot(SepalWidthCm   ~ Species, iris_data, main = "Sepal Width wrt Species", col = "antiquewhite1")
boxplot(PetalLengthCm  ~ Species, iris_data, main = "Petal Length wrt Species", col = "lightskyblue4")
boxplot(PetalWidthCm  ~ Species, iris_data, main = "Petal Width wrt Species", col = "orange1")


# Will check SepalLength Vs SepalWidth distribution using ggplot
# Also plotting linear model
g <- ggplot(iris_data, aes(x = SepalLengthCm, y = SepalWidthCm))
g <- g + geom_point(aes(shape = factor(iris_data$Species), colour = factor(iris_data$Species)))
g <- g + ggtitle (" SepalLength Vs SepalWidth wrt Species" )
g <- g + stat_smooth(method= lm)
g
## Saving the file
#dev.copy(png, file="plot1.PNG", width = 480, height = 480)
#dev.off()



##########################


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#install.packages("esquisse")
#script for ggplot easily
library(esquisse)
esquisse::esquisser()
